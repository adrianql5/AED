#ifndef RAMIFICACIONYPODA_H
#define RAMIFICACIONYPODA_H
#include "lista.h"



void asignacionPrecisa(int B[][N], NODO *s);

void asignacionTrivial(int B[][N], NODO *s);

#endif // RAMIFICACIONYPODA_H