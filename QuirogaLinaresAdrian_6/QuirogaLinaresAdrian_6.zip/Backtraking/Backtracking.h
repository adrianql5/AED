#ifndef BACKTRACKING_H
#define BACKTRACKING_H

#define n 3
//#define n 3

void Backtracking(int sInicial[], int B[][n], int usarUsadas) ;



#endif // BACKTRACKING_H
